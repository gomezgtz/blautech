<template>
  <form @submit.prevent="saveUser">
  <Input :user="user"/>    
  </form>
  <ListaUsuarios></ListaUsuarios>
</template>

<script>
import Input from '../components/Input'
import ListaUsuarios from '../components/ListaUsuarios'
import { mapActions } from 'vuex'
const shortid = require('shortid');
export default {
  name: 'Home',
  components: {
    Input,ListaUsuarios
  },
  data() {
    return {
      user:{
        id: '',
        name: '',
        lastName: '',
        email: '',
        age: ''
      }
    }
  },
  methods:{
    ...mapActions(['setUsers']),
    saveUser(){
      console.log(this.user);
      if(this.user.name.trim() === ""){
        alert('Esta vacio el nombre')
        return
      }
      
      console.log(this.user.id);      
      this.user.id = shortid.generate();

      this.setUsers(this.user)

      this.user = {
        id: '',
        name: '',
        lastName: '',
        email: '',
        age: 0
      }
    }
  },
}
</script>
