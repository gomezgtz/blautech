<template>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellido</th>
      <th scope="col">Correo</th>
      <th scope="col">Edad</th>
    </tr>
  </thead>
  <tbody>
    <tr v-for="item in users" :key="item.id">
      <th scope="row">{{item.id}}</th>
      <td>{{item.name}}</td>
      <td>{{item.lastName}}</td>
      <td>{{item.email}}</td>
      <td>{{item.age}}</td>
      <td>
          <button class="btn btn-danger btn-sm" @click="deleteUser(item.id)">
              Eliminar
          </button>
          <router-link
          class="btn btn-warning m-2 btn-sm"
          :to="{
              name: 'Editar',
              params: {
                  id: item.id
              }
          }">
              Editar
          </router-link>
      </td>
    </tr>
  </tbody>
</table>
</template>

<script>
import {mapState, mapActions} from 'vuex'
export default {
    computed:{
        ...mapState(['users'])
    },
    methods:{
        ...mapActions(['deleteUser'])
    }

}
</script>