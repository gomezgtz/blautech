<template>
<div class="mt-2">
  <input 
    type="text"
    class="form-control my2"
    placeholder="Ingrese nombre"
    v-model.trim="user.name"
    >
    </div>
    <div class="mt-2">
    <input 
    type="text"
    class="form-control my2"
    placeholder="Ingrese apellido"
    v-model.trim="user.lastName"
    >
    </div>
    <div class="mt-2">
    <input 
    type="email"
    class="form-control my2"
    placeholder="Ingrese correo"
    v-model.trim="user.email"
    >
    </div>
    <div class="mt-2">
    <input 
    type="number"
    class="form-control my2"
    placeholder="Ingrese edad"
    v-model.number="user.age"
    >
    </div>
    <hr>
    <button 
    class="btn btn-dark" 
    type="submit"
    :disabled="blocked"
    >
    Guardar usuario
    </button>
</template>

<script>
export default {
    props:{
        user: Object
    },
    computed:{
    blocked(){
      return this.user.name.trim() === "" ? true : false ||
      this.user.lastName.trim() === "" ? true : false ||
      this.user.email.trim() === "" ? true : false
    }
  }

}
</script>
