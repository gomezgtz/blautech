import { createStore } from 'vuex'
import router from '../router'

export default createStore({
    state:{
        users: [],
        user: {
        id: '',
        name: '',
        lastName: '',
        email: '',
        age: 0
        }
    },
    mutations: {
        load(state, payload){
            state.users = payload
        },
        set(state, payload){
            states.users.push(payload)
            localStorage.setItem('users', json.stringify([state.users]))
        },
        delete(state, payload){
            state.users = state.users.filter(item => item.id !== payload)
            localStorage.setItem('users', json.stringify([state.users]))
        },
        user(state, payload){
            if(!(state.user = state.users.find(item => item.id === payload)){
                router.push('/')
                return
            }
        },
        update(state, payload){
            state.users = state.users.map(item => item.id === payload.id ? payload : item)
            router.push('/')
            localStorage.setItem('users', json.stringify([state.users]))
        }
    },
    actions: {
        loadLocalStorage(commit){
            if(localStorage.getItem('users')){
                const users = JSON.parse(localStorage.getItem('users'))
                commit( 'load', users)
                return
            }
            localStorage.setItem('users', JSON.stringify([]))
        },
        setUsers({commit}, user){
            commit('set', user)
        },
        deleteUser({commit}, id){
            commit('delete', id)
        },
        setUser({ commit }, id){
            commit('update', id)
        },
        updateUser({ commit}, user){
            commit('update', user)
        }

    },
    modules: {

    }
})