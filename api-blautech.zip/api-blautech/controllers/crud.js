'use strict'

var Schema = require('../models/schema');

function crud(req, res) {
    if(req.params.user){
        var user = req.params.user;
    }else{
        var user = "No user detected";
    }
    res.status(200).send({
        message: "NodeJS y Express - " +user});
}

function getUser(req, res) {
    var userId = req.params.id;
    Schema.findById(userId, function (err, user) {
        if(err){
            res.status(500).send({message: "Error al buscar el usuario"});
        }else{
        if(!user){
            res.status(404).send({message: "No existe el usuario"});
        }else{
        res.status(200).send({user});
        }
    }
    });
}
function saveUser(req, res) {
    var schemaUser = new Schema();

    var params = req.body;
    schemaUser.name = params.name;
    schemaUser.lastName = params.lastName;
    schemaUser.email = params.email;
    schemaUser.age = params.age;

    schemaUser.save((err, schemaUserStored) => {
        if(err) {
            res.status(500).send({message: "Error al guardar campos"});
        }
           res.status(200).send({user: schemaUserStored});
    });
}
function updateUser(req, res) {
    var userId = req.params.id;
    var update = req.body;

    Schema.findByIdAndUpdate(userId, update, (err, userUpdated) => {
        if(err) {
            res.status(500).send({message: "Error al actualizar el usuario"});
        }else{
           res.status(200).send({user: userUpdated});
        }
    });
    res.status(200).send({
        user:update
    });
}
function deleteUser(req, res) {
    var userId = req.params.id;

    Schema.findById(userId, function (err, user) {
        if(err){
            res.status(500).send({message: "Error al buscar el usuario"});
        }
        if(!user){
            res.status(404).send({message: "No existe el usuario"});
        }else{
            user.remove(err => {
                if(err){
                    res.status(500).send({message: "El usuario no se ha eliminado"});
                }else{
                    res.status(200).send({message: "El usuario se ha eliminado"});
                }
            });
        }
    });
}
function getUsers(req, res) {
    Schema.find({}, (err, users) =>{
        if(err){
            res.status(500).send({message: "Error al guardar campos"});
        }else{
            if(!users){
            res.status(404).send({message: "No hay usuarios"});
            }else{
            res.status(200).send({users});
            }
        }
    });
}

module.exports = {
    crud,
    getUser,
    saveUser,
    deleteUser,
    updateUser,
    getUsers
}