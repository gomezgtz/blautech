'use strict'

var mongoose = require('mongoose');
var app = require('./app');
var port = process.env.PORT || 3678;

mongoose.connect('mongodb://127.0.0.1:27017/usersBlautech',(err, res)=>{
  if(err){
    throw err;
  }else{
    console.log('Conexion correcta a MONGODB');
    app.listen(port, function(){
      console.log(`API REST Funcionando en http://localhost:${port}`);
    });
  }
});
