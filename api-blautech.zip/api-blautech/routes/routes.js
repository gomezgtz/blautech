'use strict'

var express = require('express');
var CrudController = require('../controllers/crud');
var api = express.Router();

api.get('/home/:user?',  CrudController.crud);
api.get('/crud/:id?',  CrudController.getUser);
api.post('/crud',  CrudController.saveUser);
api.put('/crud/:id',  CrudController.updateUser);
api.delete('/crud/:id',  CrudController.deleteUser);
api.get('/cruds',  CrudController.getUsers);

module.exports = api;